Проект подготовлен для Overleaf.

Компилятор: XeLaTeX.
Главный файл: main.tex.

Загрузите свои скриншоты блок-схем в папку figures с ТОЧНО такими именами:
1. 01_godel_implication.png
2. 02_minimum_t_norm.png
3. 03_build_relations.png
4. 04_infer.png
5. 05_find_equal_fact.png
6. 06_direct_inference_run.png

Пока изображения отсутствуют, вместо них будут отображаться рамки-заглушки.
После загрузки PNG ничего в LaTeX менять не нужно.
